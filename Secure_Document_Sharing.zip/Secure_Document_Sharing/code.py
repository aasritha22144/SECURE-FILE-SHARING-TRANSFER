import os
import shutil
import hashlib
from twilio.rest import Client
from cryptography.fernet import Fernet
from PyQt5 import QtWidgets, QtGui, QtCore
from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QLabel, QFileDialog, QMessageBox, QLineEdit
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

UPLOADS_FOLDER = "uploads"
ENCRYPTED_FOLDER = "encrypted"
KEY_FILE = "key.key"
VERSIONS_FOLDER = "versions"

SENDER_EMAIL = "aasrithareddysg@gmail.com"
SENDER_PASSWORD = "zrfm fhnp xerg bjaq"

TWILIO_ACCOUNT_SID = "AC8d3ea9b5bfc25a6d98023ccc831a4528"
TWILIO_AUTH_TOKEN = "d96c9d7df5c7cf60bc6b121319c73956"
TWILIO_PHONE_NUMBER = "+916305356367"

try:
    twilio_client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
except Exception as e:
    print("Error initializing Twilio client:", e)


class FileSharingServer:
    def __init__(self):
        if not os.path.exists(UPLOADS_FOLDER):
            os.makedirs(UPLOADS_FOLDER)
        if not os.path.exists(ENCRYPTED_FOLDER):
            os.makedirs(ENCRYPTED_FOLDER)
        if not os.path.exists(VERSIONS_FOLDER):
            os.makedirs(VERSIONS_FOLDER)
        if not os.path.exists(KEY_FILE):
            key = Fernet.generate_key()
            with open(KEY_FILE, "wb") as key_file:
                key_file.write(key)
        else:
            with open(KEY_FILE, "rb") as key_file:
                self.key = key_file.read()
                self.cipher = Fernet(self.key)

    def encrypt_file(self, file_name, data):
        encrypted_data = self.cipher.encrypt(data)
        encrypted_file_path = os.path.join(ENCRYPTED_FOLDER, file_name)
        with open(encrypted_file_path, "wb") as file:
            file.write(encrypted_data)
        return encrypted_file_path

    def decrypt_file(self, file_name):
        encrypted_file_path = os.path.join(ENCRYPTED_FOLDER, file_name)
        with open(encrypted_file_path, "rb") as file:
            encrypted_data = file.read()
        decrypted_data = self.cipher.decrypt(encrypted_data)
        return decrypted_data

    def hash_file(self, data):
        hash_object = hashlib.sha256()
        hash_object.update(data)
        return hash_object.hexdigest()

    def upload_file(self, file_name, data, show_encryption_process=False):
        file_path = os.path.join(UPLOADS_FOLDER, file_name)
        if os.path.exists(file_path):
            return None  # File already exists
        with open(file_path, "wb") as file:
            file.write(data)
        if show_encryption_process:
            print("Starting encryption process...")
            print("Step 1: Reading file content.")
            print("Step 2: Encrypting file content.")
        encrypted_file_path = self.encrypt_file(file_name, data)
        return file_name, encrypted_file_path  # Return both file name and encrypted file path

    def download_file(self, file_name):
        file_path = os.path.join(UPLOADS_FOLDER, file_name)
        if os.path.exists(file_path):
            with open(file_path, "rb") as file:
                return file.read()
        else:
            return None

    def list_files(self):
        return os.listdir(UPLOADS_FOLDER)

    def create_version(self, file_name):
        file_path = os.path.join(UPLOADS_FOLDER, file_name)
        if os.path.exists(file_path):
            with open(file_path, "rb") as file:
                data = file.read()
            hash_value = self.hash_file(data)
            version_folder = os.path.join(VERSIONS_FOLDER, file_name)
            if not os.path.exists(version_folder):
                os.makedirs(version_folder)
            version_file_path = os.path.join(version_folder, hash_value)
            if not os.path.exists(version_file_path):
                shutil.copy(file_path, version_file_path)
                return True
        return False


class FileSharingClient:
    def __init__(self, server):
        self.server = server

    def send_email_notification(self, uploaded_file_name, encrypted_file_path, receiver_email):
        # Email content
        subject = f"File '{uploaded_file_name}' Upload Notification"
        body = f"File '{uploaded_file_name}' has been uploaded and stored. Please find the encrypted file attached."

        # Create MIME object
        msg = MIMEMultipart()
        msg['From'] = SENDER_EMAIL
        msg['To'] = receiver_email
        msg['Subject'] = subject

        # Attach the body to the email
        msg.attach(MIMEText(body, 'plain'))

        # Attach the encrypted file to the email
        with open(encrypted_file_path, 'rb') as attachment:
            part = MIMEBase('application', 'octet-stream')
            part.set_payload(attachment.read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', f'attachment; filename=encrypted_{uploaded_file_name}')
            msg.attach(part)

        # Start SMTP session and send email
        try:
            server = smtplib.SMTP('smtp.gmail.com', 587)
            server.starttls()
            server.login(SENDER_EMAIL, SENDER_PASSWORD)
            text = msg.as_string()
            server.sendmail(SENDER_EMAIL, receiver_email, text)
            server.quit()
            print("Email notification sent successfully.")
        except Exception as e:
            print("Error sending email notification:", e)

    def upload_file(self, file_path, receiver_email):
        show_encryption_process = QMessageBox.question(None, "Encryption Process", "Do you want to see the encryption process?", QMessageBox.Yes | QMessageBox.No)
        if show_encryption_process == QMessageBox.Yes:
            show_encryption_process = True
        else:
            show_encryption_process = False
        
        if not os.path.exists(file_path):
            QMessageBox.critical(None, "File Not Found", f"File '{file_path}' not found.")
            return None
        file_name = os.path.basename(file_path)
        with open(file_path, "rb") as file:
            data = file.read()
        uploaded_file_name, encrypted_file_path = self.server.upload_file(file_name, data, show_encryption_process=show_encryption_process)
        if uploaded_file_name:
            self.send_sms_notification(uploaded_file_name, encrypted_file_path, receiver_email)  # Send SMS notification
            self.send_email_notification(uploaded_file_name, encrypted_file_path, receiver_email)  # Send email notification
            return uploaded_file_name
        else:
            QMessageBox.critical(None, "File Upload Failed", "File already exists on the server.")
            return None

    def send_sms_notification(self, uploaded_file_name, encrypted_file_path, receiver_email):
        # Construct SMS message
        sms_message = f"File '{uploaded_file_name}' has been uploaded, encrypted, and stored at '{encrypted_file_path}'."

        # Send SMS using Twilio API
        try:
            twilio_client.messages.create(
                to=receiver_email,
                from_=TWILIO_PHONE_NUMBER,
                body=sms_message
            )
            print("SMS notification sent successfully.")
        except Exception as e:
            print("Error sending SMS notification:", e)

    def download_file(self, file_name, destination_folder):
        while not os.path.exists(destination_folder):
            QMessageBox.critical(None, "Folder Not Found", "Destination folder does not exist.")
            destination_folder = QFileDialog.getExistingDirectory(None, "Select Destination Folder")
        if file_name:
            data = self.server.download_file(file_name)
            if data:
                file_path = os.path.join(destination_folder, file_name)
                with open(file_path, "wb") as file:
                    file.write(data)
                return file_path
            else:
                QMessageBox.critical(None, "File Not Found", f"File '{file_name}' not found on the server.")
                return None
        else:
            QMessageBox.critical(None, "File Name Not Provided", "File name not provided.")
            return None

    def list_files(self):
        return self.server.list_files()

    def create_version(self, file_name):
        return self.server.create_version(file_name)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Secure Document Sharing")


        self.output_label = QLabel("", self)
        self.output_label.setGeometry(50, 200, 500, 100)  # Adjust size as needed
        self.output_label.setAlignment(QtCore.Qt.AlignCenter)
        self.output_label.setStyleSheet("font-size: 16px;")
        self.output_label.setWordWrap(True)  # Enable word wrap
        self.output_label.setScaledContents(True)  # Enable scaling

        self.choice_button = QPushButton("Submit", self)
        self.choice_button.setGeometry(225, 150, 150, 30)
        self.choice_button.setStyleSheet("font-size: 14px;")
        self.choice_button.clicked.connect(self.handle_choice)

        self.receiver_email_label = QLabel("Receiver Email:", self)
        self.receiver_email_label.setGeometry(50, 100, 100, 30)
        self.receiver_email_label.setStyleSheet("font-size: 14px;")

        self.receiver_email_input = QLineEdit(self)
        self.receiver_email_input.setGeometry(160, 100, 200, 30)
        self.receiver_email_input.setStyleSheet("font-size: 14px;")

        self.previous_executions_label = QLabel("Previous Executions:", self)
        self.previous_executions_label.setGeometry(50, 350, 500, 30)
        self.previous_executions_label.setStyleSheet("font-size: 16px; font-weight: bold;")

        self.previous_executions_text = QLabel("", self)
        self.previous_executions_text.setGeometry(50, 400, 500, 150)  # Adjust size as needed
        self.previous_executions_text.setStyleSheet("font-size: 14px;")
        self.previous_executions_text.setWordWrap(True)  # Enable word wrap
        self.previous_executions_text.setScaledContents(True)  # Enable scaling

        self.previous_executions = []

    def handle_choice(self):
        user_choice, ok = QtWidgets.QInputDialog.getText(self, 'User Choice', "Enter 'U' to upload a file or 'Q' to quit:")
        if ok:
            self.choice_var = user_choice.strip().upper()
            client = FileSharingClient(server)
            receiver_email = self.receiver_email_input.text()  # Get receiver email from input field
            if self.choice_var == 'U':
                file_path, _ = QFileDialog.getOpenFileName(self, "Select File to Upload")
                if file_path:
                    uploaded_file_name = client.upload_file(file_path, receiver_email)
                    if uploaded_file_name:
                        self.output_label.setText(f"File uploaded successfully: {uploaded_file_name}")
                        self.previous_executions.append(f"Uploaded file: {uploaded_file_name}")
            # Handle other user choices similarly...
        self.update_previous_executions()

    def update_previous_executions(self):
        self.previous_executions_text.setText("\n".join(self.previous_executions))
        for execution in self.previous_executions:
            print(execution)


if __name__ == "__main__":
    app = QApplication([])
    server = FileSharingServer()
    window = MainWindow()
    window.setGeometry(200, 200, 800, 800)
    window.show()
    app.exec_()
